# Quick Start Guide

## Installation

1. **Install dependencies:**
```bash
pip install -r requirements.txt
```

2. **Configure database:**
```bash
cp .env.example .env
# Edit .env with your database credentials
```

3. **Update database settings:**
Edit `.env` file:
```
DB_HOST=your_database_host
DB_PORT=5432
DB_NAME=your_database_name
DB_USER=your_database_user
DB_PASSWORD=your_database_password
```

## Running the Application

```bash
python main.py
```

The API will be available at: `http://localhost:8000`

API documentation: `http://localhost:8000/docs`

## Testing with Sample Invoice

```bash
curl -X POST http://localhost:8000/api/v1/invoice/process \
  -H "Content-Type: application/json" \
  -d @sample_invoice.json
```

## Expected Response

```json
{
  "status": "success",
  "message": "Invoice processed successfully",
  "grn_number": "5000123456",
  "grn_id": "500012345624X",
  "po_number": "1100877288",
  "details": {
    "grn_header_id": "uuid-here",
    "grn_lines_inserted": 1,
    "po_header_id": "uuid-here",
    "po_lines_inserted": 1,
    "po_conditions_inserted": 1
  },
  "errors": []
}
```

## Key Features

### ✅ Enterprise Patterns
- No caching - database is source of truth
- INSERT ON CONFLICT for idempotency
- Proper error handling

### ✅ Tax Rate Handling
- Composite naming: "CGST_SGST_18" for CGST 9% + SGST 9%
- Automatic combination of tax components

### ✅ Data Integrity
- Never generates PO numbers
- Never alters invoice data
- Uses exactly what OCR provides

## Troubleshooting

### Connection Error
- Check database credentials in `.env`
- Ensure database is running and accessible
- Verify network connectivity

### Tax Rate Error
- System automatically creates tax rates
- Uses composite naming for multiple taxes
- Check logs for details

### Missing PO Number
- System will create GRN without PO if PO number not in OCR input
- This is expected behavior

## Project Structure

```
.
├── api/               # FastAPI endpoints
├── database/          # Database connection
├── logs/             # Logging configuration
├── models/           # Pydantic models
├── services/         # Business logic
├── utils/            # Utility functions
├── config.py         # Configuration
├── main.py           # FastAPI app
└── README.md         # Detailed documentation
```

## Next Steps

1. Review README.md for detailed fixes
2. Test with your own invoice data
3. Monitor logs for any issues
4. Configure production settings
